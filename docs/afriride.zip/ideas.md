# AfriRide Website Design Brainstorm

## Overview
AfriRide is a Nigerian ride-sharing platform targeting South West Nigeria (Lagos, Ibadan, Abeokuta). The brand emphasizes local identity, safety, affordability, and community empowerment.

---

<response>
## Idea 1: Afrofuturism Meets Urban Mobility
<probability>0.08</probability>

### Design Movement
**Afrofuturism** - A cultural aesthetic that blends African traditions with futuristic technology, celebrating African identity while projecting forward into a tech-enabled future.

### Core Principles
1. **Bold Geometric Patterns** - Inspired by Yoruba Adire textile patterns, integrated into backgrounds and UI elements
2. **Vibrant Earth Tones** - Deep terracotta, golden amber, forest green, and midnight indigo
3. **Dynamic Motion** - Everything feels alive and in motion, reflecting Lagos energy
4. **Cultural Pride** - Every element whispers "Made in Nigeria"

### Color Philosophy
- **Primary:** Deep Terracotta (#C35831) - Warmth, earth, Nigerian soil
- **Secondary:** Golden Amber (#E8A838) - Prosperity, sunshine, optimism
- **Accent:** Forest Green (#1B5E20) - Growth, nature, Nigerian flag
- **Dark:** Midnight Indigo (#1A1A2E) - Sophistication, night rides
- **Light:** Warm Cream (#FDF6E3) - Clean, welcoming, readable

### Layout Paradigm
**Diagonal Flow Architecture** - Sections cut at angles (10-15°), creating a sense of forward movement. Content flows like Lagos traffic - organized chaos with clear direction. Hero section spans full viewport with asymmetric text placement.

### Signature Elements
1. **Adire-inspired dividers** - Geometric patterns separating sections
2. **Floating phone mockups** - 3D perspective showing the app
3. **Animated route lines** - SVG paths that draw themselves, mimicking GPS routes

### Interaction Philosophy
Interactions feel like a conversation - responsive, warm, immediate. Buttons have subtle pulse animations. Hover states reveal hidden cultural motifs. Scrolling triggers parallax effects on geometric backgrounds.

### Animation
- Hero text reveals character-by-character with a typewriter effect
- Stats count up when scrolled into view
- Cards lift and cast deeper shadows on hover
- Background patterns slowly rotate (0.5° per second)
- Page transitions use diagonal wipes

### Typography System
- **Display:** "Playfair Display" (serif) - Headlines, hero text - conveys establishment and trust
- **Body:** "DM Sans" (sans-serif) - Clean, modern, highly readable
- **Accent:** "Space Grotesk" (geometric sans) - CTAs, numbers, stats
</response>

---

<response>
## Idea 2: Lagos Street Culture Minimalism
<probability>0.06</probability>

### Design Movement
**Neo-Brutalism with African Soul** - Raw, honest design that doesn't hide behind polish. Inspired by Lagos street art, hand-painted signs, and the authentic visual language of Nigerian markets.

### Core Principles
1. **Raw Authenticity** - Imperfect is perfect; hand-drawn elements mixed with sharp typography
2. **High Contrast** - Black backgrounds with explosive color accents
3. **Typography as Art** - Words become visual elements, not just text
4. **Street Energy** - The chaos and beauty of Lagos streets distilled into digital form

### Color Philosophy
- **Primary:** Electric Yellow (#FFE500) - Danfo buses, energy, visibility
- **Secondary:** Hot Coral (#FF6B6B) - Passion, urgency, Nigerian sunsets
- **Accent:** Neon Green (#39FF14) - Go, action, mobile money
- **Dark:** Pure Black (#0A0A0A) - Night, sophistication, contrast
- **Light:** Off-White (#F5F5F0) - Breathing room, clarity

### Layout Paradigm
**Stacked Blocks with Overlap** - Large, chunky sections that slightly overlap each other. Text breaks out of containers. Images have thick black borders. Nothing is perfectly aligned - intentional 2-3px offsets create energy.

### Signature Elements
1. **Hand-drawn underlines** - Scribbled emphasis under key words
2. **Sticker-style badges** - "Safe Rides", "Local", "24/7" as rotated stickers
3. **Oversized numbers** - Stats displayed at 200px+ font size

### Interaction Philosophy
Interactions are punchy and immediate. No subtle fades - elements snap into place. Hover states add thick borders. Clicks produce satisfying "thunk" micro-animations. The site feels like it has weight.

### Animation
- Elements slide in from edges with spring physics
- Text scrambles before resolving (like a slot machine)
- Buttons have a "press down" 3D effect
- Scrolling reveals content in staggered blocks
- Cursor leaves a brief trail on dark sections

### Typography System
- **Display:** "Anton" (condensed sans) - Massive, bold, unapologetic headlines
- **Body:** "Work Sans" (humanist sans) - Friendly, approachable body text
- **Accent:** "Permanent Marker" (handwritten) - Annotations, emphasis
</response>

---

<response>
## Idea 3: Premium Tech Elegance
<probability>0.07</probability>

### Design Movement
**Scandinavian Minimalism with African Warmth** - Clean, sophisticated design that breathes luxury while maintaining cultural warmth. Think Apple meets African hospitality.

### Core Principles
1. **Generous Whitespace** - Let elements breathe; less is more
2. **Subtle Gradients** - Soft color transitions that add depth without distraction
3. **Micro-interactions** - Every element responds with grace
4. **Trust Through Clarity** - Clean design builds confidence

### Color Philosophy
- **Primary:** Deep Teal (#0D7377) - Trust, stability, professionalism
- **Secondary:** Warm Gold (#C9A227) - Premium, success, Nigerian wealth
- **Accent:** Soft Coral (#E07A5F) - Human warmth, approachability
- **Dark:** Charcoal (#2D3436) - Sophistication without harshness
- **Light:** Pearl White (#FAFAFA) - Clean, premium, spacious

### Layout Paradigm
**Asymmetric Grid with Floating Elements** - Content organized in an invisible 12-column grid, but elements break free. Phone mockups float with subtle shadows. Text blocks align left while images push right. Sections have varying heights creating rhythm.

### Signature Elements
1. **Glassmorphism cards** - Frosted glass effect on feature cards
2. **Gradient orbs** - Soft, blurred color shapes in backgrounds
3. **Thin line illustrations** - Custom icons with consistent 1.5px stroke

### Interaction Philosophy
Interactions feel effortless and premium. Everything glides smoothly. Hover states are subtle - slight lifts, gentle glows. The experience should feel like using a luxury product.

### Animation
- Fade-up reveals with 0.6s ease-out timing
- Parallax scrolling on background elements (0.3x speed)
- Cards have subtle floating animation (3px up/down, 4s loop)
- Gradient backgrounds slowly shift hue (60s cycle)
- Loading states use elegant skeleton screens

### Typography System
- **Display:** "Outfit" (geometric sans) - Modern, clean, trustworthy headlines
- **Body:** "Source Sans Pro" (humanist sans) - Excellent readability, professional
- **Accent:** "Fraunces" (soft serif) - Testimonials, quotes, warmth
</response>

---

## Selected Approach: Idea 1 - Afrofuturism Meets Urban Mobility

This approach best captures AfriRide's mission of being authentically Nigerian while projecting technological sophistication. The Afrofuturist aesthetic celebrates Nigerian identity, the warm earth tones feel welcoming and trustworthy, and the dynamic motion reflects the energy of Lagos. This design will stand out from competitors like Bolt and Uber who use generic tech aesthetics.

### Implementation Notes
- Use Playfair Display for hero headlines, DM Sans for body
- Primary color: Terracotta (#C35831), Secondary: Golden Amber (#E8A838)
- Implement diagonal section dividers with Adire-inspired patterns
- Generate custom hero images showing Nigerian streets and riders
- Add floating phone mockups with 3D perspective
- Animate route lines and stats counters
